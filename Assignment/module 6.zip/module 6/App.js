
import './App.css';
import  Section1 from './components/Section1';

function App() {



  return (
    <>
     <Section1/>


    </>
  );
}

export default App;
